intercept_k <-
function(ds, k) {

    if (is.list(ds))
        ds <- sapply(ds, "[", c(1:k))
    else {
        row_ <- NULL
        if (is.matrix(ds)) {
            row_ <- nrow(ds)
            if (k > row_) k <- row_
            else if (k < row_) ds<-ds[c(1:k)]
        }            
        else { 
            row_ <- length(ds)
            if (k > row_) k <- row_
            else if (k < row_) ds <- ds[c(1:k),]
        }
    }
    return(ds)
}
