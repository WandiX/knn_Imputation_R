intercept_L <-
function(quad_order, L) {
    len <- length(quad_order)

    for (i in 1:len) {
        li <- lapply(quad_order[[i]], sort)
        len_li <- length(li)
        for (j in 1:len_li) {
            if (li[[j]] > L) {
                if (j == 1) {
                    return(NULL)
                }
                else
                    quad_order[[i]] <- li[1:(j-1)]
                break;
            }
        }
    }
    return(quad_order)
}
