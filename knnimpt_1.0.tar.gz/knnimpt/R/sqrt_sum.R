sqrt_sum <-
function(r) {
    res <- sqrt(sum(r^2))
    return(res)
}
