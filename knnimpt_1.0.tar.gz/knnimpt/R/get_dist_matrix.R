get_dist_matrix <-
function(ds, posNA) {

    row_num <- nrow(posNA)
    res <- matrix(, nrow=row_num, ncol=nrow(ds))
    for (r in 1:row_num) {
        row_pos <- posNA[r,]
        row_ds <- ds[row_pos[1],-row_pos[2]]
        ds_rm <- ds[-posNA[,1],-row_pos[2]]
        ds_rm <- ds_rm[complete.cases(ds_rm),]
        ds_norml <- norml(ds_rm)
        res_row <- apply(ds_rm, 1, compute_dist, row1=row_ds)
        rows <- strtoi(rownames(data.frame(res_row)))
        res[r, rows] <- res_row  
        
    }
    return(res)
}
