intercept_k_quad <-
function(li, k) {
    len <- length(li)
    if (k >= len) return(li) 
    else return(li[1:k])
}
