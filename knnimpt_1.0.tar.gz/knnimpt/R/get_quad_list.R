get_quad_list <-
function(sqrtSum, quad_vec) {
    
    row_num <- NULL
    if (is.vector(quad_vec))
        row_num <- 1
    else
        row_num <- nrow(quad_vec)
    
    quad_list <- list();
    rowNames <- row.names(quad_vec)
    i = 1
    while (row_num > 0) {
        if (is.vector(quad_vec))
            curr <- quad_vec
        else
            curr <- quad_vec[1,]
        li <- NULL
        rm_list <- NULL
        for (r in 1:row_num) {
            ind <- rowNames[1]
            if (is.vector(quad_vec)) {
                cmp <- quad_vec
            }
            else {
                cmp <- quad_vec[r, ]
                ind <- rowNames[r]
            }
            if (isEqual(curr, cmp)) {
                li <- c(li, sqrtSum[r])
                rm_list <- c(rm_list, ind)
            }
        }
        names(li) <- rm_list

        if (is.vector(quad_vec))
            row_num <- 0
        else {
            quad_vec <- quad_vec[-which(row.names(quad_vec)%in%rm_list),]
            rowNames <- rowNames[!rowNames%in%rm_list]
            if (is.vector(quad_vec)) {
                row_num <- 1
            }
            else {
                row_num <- nrow(quad_vec) 
            }
        }
        
        quad_list[[i]] <- li
        i <- i+1
    }

    return(quad_list)
}
