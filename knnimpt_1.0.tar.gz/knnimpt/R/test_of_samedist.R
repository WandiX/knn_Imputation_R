test_of_samedist <-
function(dataset, dadj_val){
    datasetWithNoNulls <- na.omit(dataset)
    if (ks.test(dadj_val, datasetWithNoNulls)$p.value > 0.05){
        return (dadj_val)
    }
    else {
        return (dataset)
    }
}
