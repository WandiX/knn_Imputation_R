get_symbol <-
function(col_) {
    if (col_ > 0) return(1)
    else return(0)
}
