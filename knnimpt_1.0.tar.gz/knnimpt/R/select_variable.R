select_variable <-
function (i, dataset){
    temp <- lm(dataset[,i] ~ dataset[, 1:(i-1)] + dataset[, (i+1):dim(dataset)[2]])
    pr_tvalue <- temp$coefficients[, 4]
    list_variable_name <- dataset[0,][-i] #construct a vector of names without no.i
    for (j in length(pr_tvalue)){
        variable_list <- c()
        if (pr_tvalue[j] < 0.05){
            append(variable_list, list_variable_name[j])
        }
    }
    return (variable_list)
}
