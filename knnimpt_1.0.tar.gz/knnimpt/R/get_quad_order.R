get_quad_order <-
function(ds, posNA, k) {

    row_num <- 1
    if (is.matrix(posNA))
        row_num <- nrow(posNA)
    curr <- NULL
    lists <- NULL
    for (r in 1:row_num) {
        if (is.vector(posNA))
            curr <- posNA
        else
            curr <- posNA[r,]
        row_ <- ds[curr[1],-curr[2]]
        ds_rm <- ds[-posNA[,1], -curr[2]]
        ds_rm <- ds_rm[complete.cases(ds_rm),]
        val <- do.call(rbind, apply(ds_rm, 1, "-", row_))
        sqrtSum <- apply(val, 1, sqrt_sum)
        quad_vec <- do.call(rbind, apply(val, 1, get_quad))
        quad_list <- get_quad_list(sqrtSum, quad_vec)
        quad_list <- lapply(quad_list, sort)
        if (k != 0) quad_list <- lapply(quad_list, intercept_k_quad, k=k)
        merged_list <- unlist(quad_list)
        lists[[r]] <- merged_list
    }

    return(lists)
}
