isEqual <-
function(row1, row2) {
    
    isequal <- TRUE
    len <- length(row1)
    for (r in 1:len) {
        if (row1[[r]] != row2[[r]]) {
            isequal <- FALSE
            break
        }
    }
    
    return(isequal)
}
