get_quad_val <-
function(dataset, posNA, L, k, method) {

    nrow_pos <- nrow(posNA)
    
    quad_order <- get_quad_order(dataset, posNA, k)
    
    if (L < 0) {
        med <- median(unlist(quad_order))
        res <- intercept_L(quad_order, med)
        quad_order <- res
    }
    else if (L > 0) {
        res <- intercept_L(quad_order, L)
        if (is.null(res)) return(NULL)   #If L is too small so that some NAs don't have nearest data points
        quad_order <- res
    }
    for (i in 1:nrow_pos) {
        li <- NULL
        if (!is.list(quad_order))    #When there is only one missing value
            li <- quad_order
        else
            li <- quad_order[[i]]
        col_ind <- names(li)
        if (nrow_pos == 1) {
            col_val<-dataset[col_ind, posNA[2]]
            if (length(col_val) == 1) dataset[posNA[1], posNA[2]] <- col_val
            else {
                if (method == "weighted") {
                    t_ <- 1 / li
                    t_sum <- sum(t_)
                    weight <- t_ / t_sum
                    weight[is.nan(weight)] = 0
                    dataset[posNA[1], posNA[2]] <- sum(weight * col_val)
                }
                else {
                    dataset[posNA[1], posNA[2]] <- mean(col_val)
                }
            }
        }
        else {
            col_val<-dataset[col_ind, posNA[i,2]]
            if (length(col_val) == 1) dataset[posNA[i,1], posNA[i,2]] <- col_val
            else {
                if (method == "weighted") {
                    t_ <- 1 / li
                    t_sum <- sum(t_)
                    weight <- t_ / t_sum
                    weight[is.nan(weight)] = 0
                    dataset[posNA[i,1], posNA[i,2]] <- sum(weight * col_val)
                }
                else {
                    dataset[posNA[i,1], posNA[i,2]] <- mean(col_val, na.rm = TRUE)
                }
            }
        }
    }
    return(dataset)

}
