get_quad <-
function(r) {
    quad <- lapply(r, get_symbol)
    return(quad)
}
