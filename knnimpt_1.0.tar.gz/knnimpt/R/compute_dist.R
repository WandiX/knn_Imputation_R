compute_dist <-
function(row1, row2) {
    return(sqrt(sum((row1-row2)^2, na.rm = TRUE)))
}
