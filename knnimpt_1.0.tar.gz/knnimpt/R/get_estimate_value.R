get_estimate_value <-
function(method, dataset, d_order, posNA, dm) {
    
    nrow_pos <- nrow(posNA)
    
    #If ig == TRUE, there is no need to do computation
    ig <- ((is.vector(d_order) && length(d_order) > 1 && nrow_pos > 1) || (is.vector(d_order) && length(d_order) == 1 && nrow_pos == 1))
        
    weight <- NULL
    if (!ig && method == "weighted") {

        t_ <- 1 / dm
        
        if (is.vector(dm)) {
            t_sum <- sum(t_)
            weight <- t_ / t_sum
        }
        else  {
            t_sum <- colSums(t_)
            weight <- apply(t_, 1, "/", t_sum)
        }
        
    }
    
    for (i in 1:nrow_pos) {
        pos <- NULL
        ord <- NULL
        
        #Only one nearest data point
        if (ig) {
            ord <- d_order[i]
        }
        else {
            if (is.vector(d_order))
                ord <- d_order
            else
                ord <- d_order[,i]      
        }
        
        #Only one missing value    
        if (nrow_pos == 1)
            pos <- posNA
        else
            pos <- posNA[i,]
        
        ds_use <- dataset[ord, pos[2]]
        print(ds_use)
        ds_use <- ds_use[!is.na(ds_use)]
        
        if (ig) {
            print("hello")
            dataset[pos[1], pos[2]] <- ds_use
        }
        else {
            est <- NULL
            if (method == "weighted") {
                w <- NULL
                if (is.vector(weight))
                    w <- weight
                else
                    w <- weight[i,]
                w[is.nan(w)] = 0
                est <- sum(ds_use*w)
            }
            else {
                est <- mean(ds_use)
            }
            
            dataset[pos[1], pos[2]] <- est 
        }
                   
    }

    return(dataset)
}
