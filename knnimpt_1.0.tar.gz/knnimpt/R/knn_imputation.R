knn_imputation <-
function(dataset, k=0, method='weighted', distance='euclidean', L=0) {

    #Get the positions of NA
    posNA <- which(is.na(dataset), arr.ind=TRUE)
    nrow_pos <- nrow(posNA)
    if (nrow_pos == 0 || is.vector(dataset)) return(NULL)
    
    ds_row <- nrow(dataset)
    if (k > ds_row) k <- ds_row
    if (k < 1) k <- ds_row
    
    
    if (distance == "quad") {
        dataset <- get_quad_val(dataset, posNA, L, k, method)
        return(dataset)
    }
    
    if (distance != "euclidean") return(NULL)
    dm <- get_dist_matrix(dataset, posNA)
    d_order <- NULL
    if (is.vector(dm))
        d_order <- order(dm, na.last=NA)
    else
        d_order <- apply(dm, 1, order, na.last=NA)
    d_order <- intercept_k(d_order, k)
    dm <- apply(dm, 1 ,sort)
    dm <- intercept_k(dm, k)
    dataset <- get_estimate_value(method, dataset, d_order, posNA, dm)
    
    return(dataset)
}
